﻿LazyRouting.SetRoute({
    '/home': null,
    '/ite': null,
    '/eosio': null
});

LazyRouting.SetMirror({
    '/': '/home'
});